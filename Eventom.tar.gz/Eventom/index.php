<?php
session_start();

		if(isset($_GET['page']))
		{
			$page=$_GET['page'];
		}
		else
		{
			$page=null;
		}
?>
<html lang="en">

<head>
    <title>Event's Creators</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/stylish-portfolio.css" rel="stylesheet">
    <!-- Google icon CSS -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

    

</head>

<body>

   
    
   
	
	<?php
		if(isset($_GET['page']))
		{
			$page=$_GET['page'];
			$filename = 'pages/'.$page.'.php';
		}
		else
		{
			$filename = 'index.php';
		}

				if (file_exists($filename)) {
				    
					
					include('pages/core/nevigation.php');
					
					include('pages/core/header.php');
					
					if(isset($_GET['page']))
					{
						include('pages/'.$page.'.php');
					}

					if($page!="user" && $page!="seller" && $page!="admin" ) 
					{ 
						include('pages/core/about.php');
						include('pages/core/services.php'); 
						include('pages/core/poster.php');
						include('pages/core/our_work.php');
						include('pages/core/query_form.php');
						include('pages/core/map.php');
					}
					include('pages/core/footer.php');
 
				} else {
				    
					include('pages/error.php');
				}
			
		
		
		
	?>


    
    

    <!-- jQuery -->
    <script src="js/jquery.js"></script>
	
	<!-- JQuery JS -->
	<script src="js/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/custom_thems.js"></script>

</body>

</html>
