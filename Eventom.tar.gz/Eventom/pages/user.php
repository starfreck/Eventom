<?php 
if($_SESSION['sid']==session_id() && $_SESSION['login_type']=='user')
	{
?>
   
    <!-- Portfolio -->
    <section id="portfolio" class="portfolio">
        <div class="container">
		<div class="row">
			<div class="col-sm-12 text-center" style="background-color: lightblue; color: white;">
				<?php echo "<h1><i class=\"material-icons\" style=\"font-size:36px\">face</i><sup><sup><i class=\"material-icons\">message</i></sup></sup> Hello, \"". $_SESSION["email"]."\" Welcome to Event's Creators....</h1>"?>
			</div>
		</div><hr/><hr/>
		<div class="row" id="actions">
			<div class="col-sm-3 text-center">
				<h2>Menu</h2><hr/>
                                    
				<a href="index.php?page=user&subpage=user_add_event"><button style="font-size:24px" type="button" class="btn btn-success btn-block btn-lg" name="Add_Events"><i class="material-icons">insert_invitation</i> | Add Events</button></a><br/><br/>
				<a href="index.php?page=user&subpage=user_view_event"><button style="font-size:24px" type="button" class="btn btn-primary btn-block btn-lg" name="View_Events"><i class="material-icons">filter_frames</i> | View Events</button></a><br/><br/>
				<a href="index.php?page=user&subpage=user_del_event"><button style="font-size:24px" type="button" class="btn btn-warning btn-block btn-lg" name="Del_Events"><i class="material-icons">event_busy</i> | Delete Events</button></a><br/><br/>
				<a href="index.php?page=user&subpage=user_feedback"><button style="font-size:24px" type="button" class="btn btn-block btn-lg" name="Feedback"><i class="material-icons">mode_edit</i> | Give Feedback</button></a><br/><br/>
				<a href="index.php?page=user&subpage=user_edit_profile"><button style="font-size:24px" type="button" class="btn btn-info btn-block btn-lg" name="Edit_profile"><i class="fa fa-drivers-license-o"></i> |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Edit Profile</button></a><br/><br/>
				<a href="index.php?page=user&subpage=user_del_account"><button style="font-size:24px" type="button" class="btn btn-danger btn-block btn-lg" name="Delete_Account"><i class="material-icons">delete_sweep</i> | Delete Account</button></a><br/><br/>
					
			</div>
			<div class="col-sm-9 text-center">
				<h2>User Actions</h2><hr/>

				<?php 
						if(isset($_GET['subpage']))
						{
							$subpage=$_GET['subpage'];
							$filename = 'pages/user/'.$subpage.'.php';
							if (file_exists($filename)) {
						
								include($filename);
							
							}
							else {
							    
								include('pages/user/user_error.php');
							}
						}
						else
						{
							$subpage=null;
							include('pages/user/user_wlc.php');
						}
							
							
				?>

				
			</div>
		</div>
	</div>

    </section>

<?php
	}
	else
	{
		header("location:index.php?page=login#loginuser");
	}
?>
   
