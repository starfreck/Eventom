<!-- Map -->
    <section id="contact" class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14827.853598877782!2d72.1229244!3d21.7041459!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xf295d6b8d9e2fa2c!2sS.S.E.C.!5e0!3m2!1sen!2sin!4v1491692142235" width="100%" height="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
		<!--<iframe width="100%" height="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Twitter,+Inc.,+Market+Street,+San+Francisco,+CA&amp;aq=0&amp;oq=twitter&amp;sll=28.659344,-81.187888&amp;sspn=0.128789,0.264187&amp;ie=UTF8&amp;hq=Twitter,+Inc.,+Market+Street,+San+Francisco,+CA&amp;t=m&amp;z=15&amp;iwloc=A&amp;output=embed"></iframe>
        --><br />
        <small>
            <!--<a href="https://maps.google.com/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Twitter,+Inc.,+Market+Street,+San+Francisco,+CA&amp;aq=0&amp;oq=twitter&amp;sll=28.659344,-81.187888&amp;sspn=0.128789,0.264187&amp;ie=UTF8&amp;hq=Twitter,+Inc.,+Market+Street,+San+Francisco,+CA&amp;t=m&amp;z=15&amp;iwloc=A"></a>
			--><a href="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14827.853598877782!2d72.1229244!3d21.7041459!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xf295d6b8d9e2fa2c!2sS.S.E.C.!5e0!3m2!1sen!2sin!4v1491692142235">
		</small>
    </section>
