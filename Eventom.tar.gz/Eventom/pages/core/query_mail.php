<?php

function query_mail($fname, $lname,$email,$msg)
{

$to      = 'vasuratanpara@gmail.com';
$subject = 'Events Creators';
$message = "  First Name=:".$fname."  Last Name:".$lname." E-mail:".$email." Message:".$msg;
$headers = 'From: Events Creators' . "\r\n" .
    'Reply-To: vasuratanpara@gmail' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
//ini_set('SMTP','myserver');
//ini_set('smtp_port',25);
mail($to, $subject, $message, $headers);
}

?>