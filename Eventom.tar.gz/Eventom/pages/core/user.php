<?php include_once('pages/user_functions.php'); ?>
	    
    <!-- Portfolio -->
    <section id="portfolio" class="portfolio">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-lg-offset-1 text-center">
                    <h2>User Actions </h2>
                    <hr class="small">
                    
				</div>
                <!-- /.col-lg-10 -->
			</div>
            <!-- /.row -->
            <aside class="call-to-action bg-primary">
        <div class="container">
            <div class="row">
				<div class="col-md-6 pull-left">
				
                            <div class="portfolio-item">

                                <a href="gallery.php">
                                 Menu<br/>
                                    <input type="submit" name="Link 1"/><br/><br/>
                                </a>
                                    <input type="submit" name="Link 2"/><br/><br/>
                                    <input type="submit" name="Link 3"/><br/><br/>
                                    <input type="submit" name="Link 4"/><br/><br/>
                                    <input type="submit" name="Link 5"/><br/><br/>
                                    <input type="submit" name="Link 6"/><br/>
                                
                            </div>
				</div>
                <div class="col-md-6 pull-right">
					<center>
					</center>
					<div class="clearfix"/>
                </div>
				
            </div>
        </div>
    </aside>
		</div>
        <!-- /.container -->
    </section>


   