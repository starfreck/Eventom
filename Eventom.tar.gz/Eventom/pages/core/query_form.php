<!-- Call to Action -->

<aside class="call-to-action bg-primary">
        <div class="container">
            <div class="row">
				<div class="col-md-6 pull-left">
				<!--feedback form image-->
                            <div class="portfolio-item">
                                <a href="gallery.php">
                                    <img class="img-portfolio img-responsive" src="img/portfolio-1.jpg">
                                </a>
                            </div>
				</div>
                <div class="col-md-6 pull-right">
					<center>
						<form action="index.php?page=login" method="post" id="sendemail">
								<h2>Hi There! Any Query ?</h2>
								<h5>E-mail us we'll happy to answer you...</h5>
								<table>
									<div class="form-group">
											<tr>
											<td><label for="name" style="color:white; margin:0px; padding:0px; font-size:13px;">First Name (required)</label></td>
											</tr>
											<tr>
											<td><input type="text" style="color:black;" class="form-control-center" id="fname" name="fname" size="30%"/><br><br></td>
											</tr>
									</div>
									<div class="form-group">
											<tr>
											<td><label for="name" style="color:white; margin:0px; padding:0px; font-size:13px;">Last Name  (required)</label></td>
											</tr>
											<tr>
											<td><input type="text" style="color:black;" class="form-control-center" id="lname" name="lname" size="30%"/><br><br></td>
											</tr>
									</div>
									<div class="form-group">
											<tr>
											<td><label for="email" style="color:white; margin:0px; padding:0px; font-size:13px;">Email Address (required)</label></td>
											</tr>
											<tr>
											<td><input type="email" style="color:black;" class="form-control-center" id="email" name="email" size="30%"/><br><br></td>
											</tr>
									</div>
									
									<div class="form-group">
											<tr>
											<td><label for="message" style="color:white; margin:0px; padding:0px; font-size:13px;">Message (required)</label></td>
											</tr>
											<tr>
											<td><textarea name="msg" style="color:black;" cols="29" id="address"></textarea><br><br></td>
											</tr>
									</div>                  
								</table>
								<table>
									<tr>
										<td><input type="submit" class="btn btn-success btn-md" name="submit" value="Send"></td>
									</tr>
								</table>
						</form>
						
						
						<?php
						
							
							include 'query_mail.php';
							
							if(isset($_POST['submit']))
							{
							$lname = $_POST['lname'];
							$fname = $_POST['fname'];
							$email = $_POST['email'];
							$msg = $_POST['msg'];
							
							query_mail($fname, $lname,$email,$msg);
							}
							
						?>
					<div class="clearfix"/>
                </div>
				
            </div>
        </div>
    </aside>