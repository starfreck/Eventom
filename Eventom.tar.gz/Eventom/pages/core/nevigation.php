<?php

if(isset($_SESSION['sid']))
{
?>
<!--Write Code Here....--> 

    <!-- Navigation -->
    <a id="menu-toggle" href="#" class="btn btn-dark btn-lg toggle"><i class="fa fa-bars"></i></a>
    <nav id="sidebar-wrapper">
        <ul class="sidebar-nav">
            <a id="menu-close" href="#" class="btn btn-light btn-lg pull-right toggle"><i class="fa fa-times"></i></a>
            <li class="sidebar-brand">
                <a href="#top" onclick=$("#menu-close").click();>Welcome User</a>
            </li>
            <li>
                <a href="index.php" onclick=$("#menu-close").click();>Home</a>
            </li>
		<?php 
			if($_SESSION["login_type"] == "admin"){?>
				<li class="label-success">
					<a href="index.php?page=admin" onclick=$("#menu-close").click();>Admin</a>
				    </li>
				
				<!--add more user login page-->
		<?php }
			elseif($_SESSION["login_type"] == "user"){?>
				<li class="label-success">
					<a href="index.php?page=user" onclick=$("#menu-close").click();>user</a>
				    </li>
				<!--add more user login page-->
		<?php }elseif($_SESSION["login_type"] == "seller"){?>
			    <li class="label-success">
				<a href="index.php?page=seller" onclick=$("#menu-close").click();>Seller</a>
			    </li>
				<!--add more seller login page-->
		
		<?php }else{?>
			    <li class="label-danger">
				<a href="index.php?page=error" onclick=$("#menu-close").click();>Error</a>
			    </li>
				<li>
				<a href="index.php?page=error" onclick=$("#menu-close").click();>error.php</a>
			    </li>
				<!--add more seller login page-->
		<?php }?>
	    <li>
                <a href="index.php?page=logout" onclick=$("#menu-close").click();>Logout</a>
            </li>
		<li>
                <a href="index.php?page=gallery#gallery" onclick=$("#menu-close").click();>Gallery</a>
            </li>
            <li>
                <a href="#contact" onclick=$("#menu-close").click();>Contact</a>
            </li>
        </ul>
    </nav>

<?php
	}
	else
	{
?>
		    
    <a id="menu-toggle" href="#" class="btn btn-dark btn-lg toggle"><i class="fa fa-bars"></i></a>
    <nav id="sidebar-wrapper">
        <ul class="sidebar-nav">
            <a id="menu-close" href="#" class="btn btn-light btn-lg pull-right toggle"><i class="fa fa-times"></i></a>
            <li class="sidebar-brand">
                <a href="#top" onclick=$("#menu-close").click();>Event's Creators</a>
            </li>
            <li class="label-success">
                <a href="index.php" onclick=$("#menu-close").click();>Home</a>
            </li>
			<li>
                <a href="index.php?page=login#loginuser" onclick=$("#menu-close").click();>Login</a>
            </li>
			<li>
                <a href="index.php?page=signup#newuser" onclick=$("#menu-close").click();>Signup</a>
            </li>
			<li>
                <a href="index.php?page=gallery#gallery" onclick=$("#menu-close").click();>Gallery</a>
            </li>
            <li>
                <a href="#about" onclick=$("#menu-close").click();>About</a>
            </li>
            <li>
                <a href="#services" onclick=$("#menu-close").click();>Services</a>
            </li>
            <li>
                <a href="#portfolio" onclick=$("#menu-close").click();>Our Work</a>
            </li>
            <li>
                <a href="#contact" onclick=$("#menu-close").click();>Contact</a>
            </li>
        </ul>
    </nav>
<?php	
	}
?>
   

