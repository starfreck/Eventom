<?php
//db details
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'event';

//$dbHost = "localhost";
//$dbUsername = "id1884051_root";
//$dbPassword = "9974146697moM";
//$dbName = "id1884051_event";

//Connect and select the database
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>
