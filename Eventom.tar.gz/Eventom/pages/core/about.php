<!-- About -->
    <section id="about" class="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>Event's Creators is the perfect for your next Event !</h2>
                    <p class="lead">We Don't Speak Our Work Speaks All</p>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </section>
