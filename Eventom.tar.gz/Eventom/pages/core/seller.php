<?php include_once('pages/seller_functions.php'); ?>
 
 <section id="portfolio" class="portfolio">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-lg-offset-1 text-center">
                    <h2>Your Events...</h2>
                    <hr class="small">
                    <div class="row">
						<div id="calendar_div">
									<?php echo getCalender(); ?>
						</div>
                        
                    </div>
				</div>
                <!-- /.col-lg-10 -->
			</div>
            <!-- /.row -->
		</div>
        <!-- /.container -->
    </section>
	