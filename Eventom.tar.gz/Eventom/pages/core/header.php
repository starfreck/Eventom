    <!-- Header -->
    <header id="top" class="header"> <!--style="display:table;position:relative;width:100%;
    height:100%;background:url(../img/bg.jpg)no-repeat center center scroll;">-->
        <div class="text-vertical-center">
            <h1 style="color:white;">Event's Creators</h1>
            <h4 style="color:white;">We Don't Speak Our Work Speaks All....</h4>
            <br>
            
			<?php
			
			


			if(isset($_SESSION['sid']))
			{
			?>
			<center>
				<table>
					<tr>
						<td><a href="index.php?page=logout" class="btn btn-danger btn-md">Logout</a></td>
					</tr>
				</table>
			</center>
			<?php
				}
				else
				{
			?>
			<a href="#about" class="btn btn-dark btn-lg">Find Out More</a><br><br>
			<center>
				<table>
					<tr>
						<td><a href="index.php?page=login#loginuser" class="btn btn-success btn-md">Login</a></td>
						<td><a href="index.php?page=signup#newuser" class="btn btn-default btn-md">Signup</a></td>
					</tr>
				</table>
			</center>
			<?php	
				}
			?>
        </div>
    </header>
