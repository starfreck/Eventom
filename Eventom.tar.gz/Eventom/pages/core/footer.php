<!-- Footer -->
    <footer id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-lg-offset-1 text-center">
                    <h4><strong>Event's Creators</strong>
                    </h4>
                    <p>D-2222 Friend's Place
                        <br>Hill Drive, Bhavnagar 364001</p>
                    <ul class="list-unstyled">
                        <li><i class="fa fa-phone fa-fw"></i> (+91) 9426064591</li>
                        <li><i class="fa fa-envelope-o fa-fw"></i> <a href="mailto:vasuratanpara@gmail.com">vasuratanpara@gmail.com</a>
                        </li>
                    </ul>
                    <br>
                    <ul class="list-inline">
                        <li>
                            <a href="www.fb.com/vasuratanpara"><i class="fa fa-facebook fa-fw fa-3x"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-twitter fa-fw fa-3x"></i></a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-dribbble fa-fw fa-3x"></i></a>
                        </li>
                    </ul>
                    <hr class="small">
                    <p class="text-muted">Copyright &copy; Event's Creators 2017</p>
		    <p class="text-muted">Proudly Created On <a src="https://www.linux.org/">Linux</a> <font style="color:red; font-size:20px;">&#9829;</font></p>
                </div>
            </div>
        </div>
        <a id="to-top" href="#top" class="btn btn-dark btn-lg"><i class="fa fa-chevron-up fa-fw fa-1x"></i></a>
    </footer>
