<!-- Services -->
    <!-- The circle icons use Font Awesome's stacked icon classes. For more information, visit http://fontawesome.io/examples/ -->
    <section id="services" class="services bg-danger">
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-10 col-lg-offset-1">
                    <h2>Our Services</h2>
		<hr>
                    <div class="row">
			    <div class="col-md-3 col-sm-6">
                            <div class="service-item">
                                <span class="fa-stack fa-4x">
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <img class="fa fa-shield fa-stack-1x text-primary" src="img/Food-Dome-512.png"></img>
                            </span>
                                <h4>
                                    <strong>Food Service</strong>
                                </h4>
                                <!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>-->
                                <!--<a href="#" class="btn btn-light">Learn More</a>-->
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-6">
                            <div class="service-item">
                                <span class="fa-stack fa-4x">
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <img class="fa fa-cloud fa-stack-1x text-primary" src="img/6ip5qjabT.png"></img>
                            </span>
                                <h4>
                                    <strong>Decoration</strong>
                                </h4>
                                <!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>-->
                                <!--<a href="#" class="btn btn-light">Learn More</a>-->
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-6">
                            <div class="service-item">
                                <span class="fa-stack fa-4x">
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <img class="fa fa-compass fa-stack-1x text-primary" src="img/110-512.png"></img>
                            </span>
                                <h4>
                                    <strong>Light Decoration</strong>
                                </h4>
                                <!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>-->
                                <!--<a href="#" class="btn btn-light">Learn More</a>-->
                            </div>
                        </div>
                        
                    

			<div class="col-md-3 col-sm-6">
                            <div class="service-item">
                                <span class="fa-stack fa-4x">
                                <i class="fa fa-circle fa-stack-2x"></i>
                                <img class="fa fa-flask fa-stack-1x text-primary" src="img/Music-icon.png"></img>
                            </span>
                                <h4>
                                    <strong>Music System</strong>
                                </h4>
                                <!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>-->
                                <!--<a href="#" class="btn btn-light">Learn More</a>-->
                            </div>
                        </div>
                    </div>
                    <!-- /.row (nested) -->
                </div>
                <!-- /.col-lg-10 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </section>

