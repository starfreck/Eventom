<?php
if($_SESSION['sid']==session_id() && $_SESSION['login_type']=='user')
{
$email=$_SESSION['email'];

include'pages/connection.php';
$conn = new mysqli($servername, $username, $password,$dbname);
if ($conn)
{

	$result_web = mysqli_query($conn,"SELECT * FROM events WHERE creator ='$email'");
	echo"<center><br><br>";
	echo "<table style=\"font-size:15px\">";
	
	echo"<tr style=\"background-color:lightblue;\">";
	echo"<td align=\"center\">&nbsp;ID&nbsp;</td><td align=\"center\">&nbsp;Title&nbsp;</td><td align=\"center\">&nbsp;Date&nbsp;</td><td align=\"center\">&nbsp;Venue&nbsp;</td><td align=\"center\">&nbsp;Facilities&nbsp;</td><td align=\"center\">&nbsp;Food&nbsp;</td><td align=\"center\">&nbsp;Decoration&nbsp;</td><td align=\"center\">&nbsp;Cost&nbsp;</td><td align=\"center\">&nbsp;Payment&nbsp;</td><td align=\"center\">&nbsp;Status&nbsp;</td>";
	echo"</tr>";
	
	$count=1;
	while($row = mysqli_fetch_array($result_web))
	{
		
		if(!($count %= 2)){echo"<tr style=\"background-color:lightgray;\">";}
		else{echo"<tr>";}
		echo"<td align=\"center\">&nbsp;".$row['id']."&nbsp;</td>";
		echo"<td align=\"center\">&nbsp;".$row['title']."&nbsp;</td>";
		echo"<td align=\"center\">&nbsp;".$row['date']."&nbsp;</td>";
		echo"<td align=\"center\">&nbsp;".$row['id']."&nbsp;</td>";
		echo"<td align=\"center\">&nbsp;".$row['facilities']."&nbsp;</td>";
		echo"<td align=\"center\">&nbsp;".$row['food']."&nbsp;</td>";
		echo"<td align=\"center\">&nbsp;".$row['decoration']."&nbsp;</td>";
		echo"<td align=\"center\">&nbsp;".$row['total_cost']."&nbsp;</td>";
		echo"<td align=\"center\">&nbsp;".$row['payment_status']."&nbsp;</td>";

		if($row['status'] == 0)
		{
			echo"<td align=\"center\" style=\"color:red\">&nbsp;Not Active&nbsp;</td>";
		}
		elseif($row['status'] == 1)
		{
			echo"<td  align=\"center\" style=\"color:green\">&nbsp;Active&nbsp;</td>";
		}
		else
		{
			echo"<td align=\"center\">&nbsp;Unknown&nbsp;</td>";
		}
		echo"</tr>";
		
		$count++;
		
	}
	echo "</table>";
	echo"</center>";
	
}
mysqli_close($conn);
}
else
{
	header("location:index.php?page=login#loginuser");
}
?>
