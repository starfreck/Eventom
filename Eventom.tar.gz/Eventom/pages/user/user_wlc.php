<div class="text-center">
<br/><br/><br/>
	    <h1><span class="glyphicon" style="font-size:75px;color:black;">&#xe001;</span></h1>
            <h1>Welcome User</h1>
            <h1><span class="glyphicon" style="font-size:50px;color:lightblue;">&#xe128;</span></h1>
	    <h3>Your Actions is in Menu</h3>
</div>
