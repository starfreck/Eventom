<?php
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "event";
		
		//$servername = "localhost";
		//$username = "";
		//$password = "";
		//$dbname = "";
		

		
?>


