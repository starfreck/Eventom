<?php
if($_SESSION['sid']==session_id() && $_SESSION['login_type']=='seller')
{
?>
 
   
    <!-- Portfolio -->
    <section id="portfolio" class="portfolio">
        <div class="container">
		<div class="row">
			<div class="col-sm-12 text-center" style="background-color: lightblue; color: white;">
				<?php echo "<h1><i class=\"material-icons\" style=\"font-size:36px\">face</i><sup><sup><i class=\"material-icons\">message</i></sup></sup> Hello, \"". $_SESSION["email"]."\" Welcome to Event's Creators....</h1>"?>
			</div>
		</div><hr/><hr/>
		<div class="row" id="actions">
			<div class="col-sm-3 text-center">
				<h2>Menu</h2><hr/>
                                    
				
				
				<a href="index.php?page=seller&subpage=seller_del_services"><button style="font-size:24px" type="button" class="btn btn-danger btn-block btn-lg" name="delete_services"><i class="material-icons">insert_invitation</i> | Delete Services</button></a><br/><br/>
				<a href="index.php?page=seller&subpage=seller_view_services"><button style="font-size:24px" type="button" class="btn btn-info btn-block btn-lg" name="view_decoration"><i class="material-icons">insert_invitation</i> | View Services</button></a><br/><br/>
				<a href="index.php?page=seller&subpage=seller_add_services"><button style="font-size:24px" type="button" class="btn btn-success btn-block btn-lg" name="add_food"><i class="material-icons">event_busy</i> | Add Services</button></a><br/><br/>
				<a href="index.php?page=seller&subpage=seller_add_venue"><button style="font-size:24px" type="button" class="btn btn-success btn-block btn-lg" name="add_venue"><i class="material-icons">event_busy</i> | Add Venue</button></a><br/><br/>
				<a href="index.php?page=seller&subpage=seller_view_event"><button style="font-size:24px" type="button" class="btn btn-primary btn-block btn-lg" name="View_Events"><i class="material-icons">filter_frames</i> | View Events</button></a><br/><br/>
				
				<a href="index.php?page=seller&subpage=seller_feedback"><button style="font-size:24px" type="button" class="btn btn-block btn-lg" name="Feedback"><i class="material-icons">mode_edit</i> | Give Feedback</button></a><br/><br/>
				<a href="index.php?page=seller&subpage=seller_edit_profile"><button style="font-size:24px" type="button" class="btn btn-info btn-block btn-lg" name="Edit_profile"><i class="fa fa-drivers-license-o"></i> |&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Edit Profile</button></a><br/><br/>
				<a href="index.php?page=seller&subpage=seller_del_account"><button style="font-size:24px" type="button" class="btn btn-danger btn-block btn-lg" name="Delete_Account"><i class="material-icons">delete_sweep</i> | Delete Account</button></a><br/><br/>
					
			</div>
			<div class="col-sm-9 text-center">
				<h2>Seller Actions</h2><hr/>

				<?php 
						if(isset($_GET['subpage']))
						{
							$subpage=$_GET['subpage'];
							$filename = 'pages/seller/'.$subpage.'.php';
							if (file_exists($filename)) {
						
								include($filename);
							
							}
							else {
							    
								include('pages/seller/seller_error.php');
							}
						}
						else
						{
							$subpage=null;
							include('pages/seller/seller_wlc.php');
						}
							
							
				?>

				
			</div>
		</div>
	</div>

    </section>

<?php
	}
	else
	{
		header("location:index.php?page=login#loginseller");
	}
?>
   
