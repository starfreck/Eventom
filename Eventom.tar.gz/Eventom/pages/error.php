
    <header id="top" class="header"> <!--style="display:table;position:relative;width:100%;
    height:100%;background:url(../img/bg.jpg)no-repeat center center scroll;">-->
	
	<br/>
	    	
        <div class="text-vertical-center">
	    <div class="text-center">
	    <h1><i class="material-icons"style="font-size:125px;color:red;">&#xe14b;</i></h1> 
            <h1 style="color:black;">404, Error</h1>
            <h1><i class="material-icons" style="font-size:75px;color:red;">&#xe160;</i></h1>
	    </div>
	    <h3 style="color:black;">Page Not Found On Server...</h3>
            <br>
            <a href="#about" class="btn btn-dark btn-lg">Find Out More</a><br><br>
			<center>
				<table>
					<tr>
						<td><a href="index.php?page=login#loginuser" class="btn btn-success btn-md">Login</a></td>
						<td><a href="index.php?page=signup#newuser" class="btn btn-default btn-md">Signup</a></td>
					</tr>
				</table>
			</center>
        </div>
    </header>
