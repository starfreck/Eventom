<?php
		include 'connection.php';
		if (isset($_SESSION['sid']))
		{
			if($_SESSION['sid']==session_id())
			{
				header("Location:index.php"); 
			}
		
				echo "<script>alert('vasu...');</script>";
				$upd=$_SESSION['email'];
				$fname_web = strval($_POST['fname']);
				$lname_web = strval($_POST['lname']);
				$email_web = strval($_POST['email']);
				$password_web = strval($_POST['password']);
				
				$dob_web = strval($_POST['dob']);
				$user_type_web = strval($_POST['user_type']);
				$gender_web = strval($_POST['gender']);
				$m_number_web = strval($_POST['mobile_number']);
				$address_web = strval($_POST['address']);
				$cityname_web = strval($_POST['city']);
				$countryname_web = strval($_POST['country']);
				// MD5 password
				$password_md5 = md5($password_web);
				//echo "$fname_web";
				//echo "$lname_web";
				//echo "$email_web";
				//echo "$password_web";
				//echo "$m_number_web";
				//echo "$dob_web";
				//echo "$address_web";
					
						// Create connection
							$conn = new mysqli($servername, $username, $password,$dbname);
						// Check connection
							if ($conn)
							{
								
								$update_web1 = "UPDATE registration SET fname='$fname_web',lname='$lname_web',email='$email_web',password='$password_web',md5password='$password_md5',mobile_no='$m_number_web',dob='$dob_web',city='$cityname_web',country='$countryname_web',gender='$gender_web',address='$address_web' WHERE email='$upd'";

								

								$update_web2 = "UPDATE login SET email='$email_web',password='$password_md5' WHERE email='$upd'";
 

									
									if(mysqli_query($conn,$update_web1) && mysqli_query($conn,$update_web2))
									{
										echo "<script>alert('Details Updation Successfully...');</script>";
										$_SESSION['email']=$_POST['email'];
										if($_POST['user_type']=="user")
										{
											header('Location: index.php?page=user&subpage=user_edit_profile#actions');
										}else{
											header('Location: index.php?page=seller&subpage=seller_edit_profile#actions');
										}
									}
									else
									{
										echo "<script>alert('Details Updation failed...');</script>";
										if($_POST['user_type']=="user")
										{
											header('Location: index.php?page=user&subpage=user_edit_profile');						}else{
											header('Location: index.php?page=seller&subpage=seller_edit_profile');
										}
									}

								mysqli_close($conn);
							}
		}
	
?>
