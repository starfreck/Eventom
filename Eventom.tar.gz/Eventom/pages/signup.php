
		<center>
				
			<form action="index.php?page=signup#newuser" method="post" id="newuser">
				<h2>Hi There! Signup Here...</h2>
				<h5>We'll get you set up on 'Events Creator' in three easy steps! Just answer a few simple questions, select an ID and password and you'll be set...</h5>
				<table>
					<div class="form-group">
							<tr>
							<td><label for="name" style="margin:0px; padding:0px; font-size:13px;">First Name (required)</label></td>
							</tr>
							<tr>
							<td><input type="text" class="form-control-center" id="fname" name="fname" size="30%"/><br><br></td>
							</tr>
					</div>
					<div class="form-group">
							<tr>
							<td><label for="name" style="margin:0px; padding:0px; font-size:13px;">Last Name  (required)</label></td>
							</tr>
							<tr>
							<td><input type="text" class="form-control-center" id="lname" name="lname" size="30%"/><br><br></td>
							</tr>
					</div>
					<div class="form-group">
							<tr>
							<td><label for="email" style="margin:0px; padding:0px; font-size:13px;">Email Address (required)</label></td>
							</tr>
							<tr>
							<td><input type="email" class="form-control-center" id="email" name="email" size="30%"/><br><br></td>
							</tr>
					</div>
					<div class="form-group">
							<tr>
							<td><label for="password" style="margin:0px; padding:0px; font-size:13px;">Password (required)</label></td>
							</tr>
							<tr>
							<td><input type="password" class="form-control-center" id="password" name="password" size="30%"/><br><br></td>
							</tr>
					</div>
					<div class="form-group">
							<tr>
							<td><label for="conformpassword" style="margin:0px; padding:0px; font-size:13px;">Conform Password (required)</label></td>
							</tr>
							<tr>
							<td><input type="password" class="form-control-center" id="conformpassword" name="conformpassword" size="30%""/><br><br></td>
							</tr>
					</div> 
					<div class="form-group">
							<tr>
							<td><label for="mobile_number" style="margin:0px; padding:0px; font-size:13px;">Mobile No. (required)</label></td>
							</tr>
							<tr>
							<td><input type="number_format" class="form-control-center" id="mobile_number" name="mobile_number" size="30%""/><br><br></td>
							</tr>
					</div> 
					<div class="form-group">
							<tr>
							<td><label for="date" style="margin:0px; padding:0px; font-size:13px;">Date Of Birth (required)</label></td>
							</tr>
							<tr>
							<td><input type="date" class="form-control-center" id="dob" name="dob" style="height:25px; width:285px;"""/><br><br></td>
							</tr>
					</div> 
					<div class="form-group">
							<tr>
							<td><label for="user_type" style="margin:0px; padding:0px; font-size:13px;">User Type  (required)</label></td>
							</tr>
							<tr>
							<td><select class="form-control-center" id="user_type" name="user_type" style="height:25px; width:285px;"/>
								<option value="user">user</option>
								<option value="seller">seller</option>
								</select><br><br></td>
							</tr>
					</div>
					<div class="form-group">
							<tr>
							<td><label for="city" style="margin:0px; padding:0px; font-size:13px;">City  (required)</label></td>
							</tr>
							<tr>
							<td><input type="text" class="form-control-center" id="city" name="city" size="30%""/><br><br></td>
							</tr>
					</div> 
					<div class="form-group">
							<tr>
							<td><label for="country" style="margin:0px; padding:0px; font-size:13px;">Country  (required)</label></td>
							</tr>
							<tr>
							<td><input type="text" class="form-control-center" id="country" name="country" size="30%""/><br><br></td>
							</tr>
					</div>        
					<div class="form-group">
							<tr>
							<td><label for="gender" style="margin:0px; padding:0px; font-size:13px;">Gender</label></td>
							</tr>
							<tr>
							<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input id="male" name="gender" type="radio" value="Male" />Male &nbsp;
							<input id="female" name="gender" type="radio" value="Female" />Female<br><br></td>
							</tr>
					</div>
					<div class="form-group">
							<tr>
							<td><label for="message" style="margin:0px; padding:0px; font-size:13px;">Address (required)</label></td>
							</tr>
							<tr>
							<td><textarea name="address" cols="30" id="address"></textarea><br><br></td>
							</tr>
					</div>                  
				</table>
				<table>
					<tr>
						<td><a href="index.php?page=login#loginuser" class="btn btn-default btn-md">Login</a></td>
						<td><input type="submit" class="btn btn-success btn-md" name="signup_button" value="Signup"></td>
					</tr>
				</table>
			</form>
		</center>
    </div>
    

<?php
	
		include 'connection.php';
		if (isset($_SESSION['sid']))
		{
			if($_SESSION['sid']==session_id())
			{
				header("Location:index.php"); 
			}
		}
		else
		{
			if(isset($_POST['signup_button']))
			{
				
				$fname_web = strval($_POST['fname']);
				$lname_web = strval($_POST['lname']);
				$email_web = strval($_POST['email']);
				$password_web = strval($_POST['password']);
				$conformpassword_web = strval($_POST['conformpassword']);
				$dob_web = strval($_POST['dob']);
				$user_type_web = strval($_POST['user_type']);
				$gender_web = strval($_POST['gender']);
				$m_number_web = strval($_POST['mobile_number']);
				$address_web = strval($_POST['address']);
				$cityname_web = strval($_POST['city']);
				$countryname_web = strval($_POST['country']);
				// MD5 password
				$password_md5 = md5($password_web);
					if($password_web != $conformpassword_web)
					{
						echo "<script>alert('Password do not match...');</script>";
					}
					else
					{
						// Create connection
							$conn = new mysqli($servername, $username, $password,$dbname);
						// Check connection
							if ($conn)
							{
								
								$insert_web1 = "INSERT INTO registration VALUES ('','$fname_web','$lname_web','$email_web','$password_web','$password_md5','$m_number_web','$dob_web','$user_type_web','$cityname_web','$countryname_web','$gender_web','$address_web')";

								

								$insert_web2 = "INSERT INTO login VALUES ('','$email_web','$password_md5','$user_type_web')";

									
									if(mysqli_query($conn,$insert_web1) && mysqli_query($conn,$insert_web2) && $fname_web!=null && $lname_web!=null && $email_web!=null && $password_web!=null && $conformpassword_web!=null && $m_number_web!=null && $dob_web!=null && $address_web!=null)
									{
										echo "<script>alert('E-Mail Registered Successfully...');</script>";
									}
									else
									{
										echo "<script>alert('E-Mail Registeration failed...');</script>";
									}

								mysqli_close($conn);
							}
					}
			}


		}
	
?>
