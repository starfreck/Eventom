<?php
	
	
	include 'connection.php';
			
			if(isset($_POST['login_button']))
			{
			
				$uname_web = $_POST['reg_email'];
				$passwd_web1 = $_POST['reg_password'];
				$passwd_web = md5($passwd_web1);
			
			

			// Create connection
				$conn = new mysqli($servername, $username, $password,$dbname);
				
			// Check connection
				if ($conn)
				{
					
					$result_web = mysqli_query($conn,"SELECT * FROM login");
					
					while($row = mysqli_fetch_array($result_web))
						{
								//echo $uname_web."<br/>";
								//echo $passwd_web1."<br/>";
								//echo $passwd_web."<br/><br/>";
								//echo $row['email']."<br/>";
								//echo $row['password']."<br/>";
								//echo $row['user_type']."<br/>";
							if($uname_web == $row['email'] && $passwd_web == $row['password'])
							{	
								
								if("admin" == $row['user_type'])
								{
									session_start();
									$_SESSION['sid']=session_id();
									$_SESSION["login_type"] = "admin";
									$_SESSION["email"] = $uname_web;
									header("Location: index.php?page=admin#actions"); 
									exit;
								}
								elseif("user" == $row['user_type'])
								{
									session_start();
									$_SESSION['sid']=session_id();
									$_SESSION["login_type"] = "user";
									$_SESSION["email"] = $uname_web;
									header("Location: index.php?page=user#actions"); 
									exit;
								}
								elseif("seller" == $row['user_type'])
								{
									session_start();
									$_SESSION['sid']=session_id();
									$_SESSION["login_type"] = "seller";
									$_SESSION["email"] = $uname_web;
									header("Location: index.php?page=seller#actions"); 
									exit;
								}
								else
								{
							
									echo "<script>alert('Sorry incorrect 'User' type... contect Admin');</script>";
									//ERROR-> if password is worng user can't see that msg 
									header("Location: index.php?page=login");
								}
							}	
							else
							{
								
								echo "<script>alert('Sorry incorrect username or password... try again');</script>";
								//ERROR-> if password is worng user can't see that msg 
								header("Location: index.php?page=login");
							}
						}	
					
					mysqli_close($conn);
				}
			}
		
		
?>
		<div class="container">
			<center>
			<form action="index.php?page=login" method="post" id="loginuser">
				<h2>Hi There! Login Here...!</h2><br>
				<table>
					<div class="form-group">
						<tr>
						<td><label for="email" style="margin:0px; padding:0px; font-size:13px;">Email Address (required)</label></td>
						</tr>
						<tr>
						<td><input type="email" class="form-control-center" id="reg_email" name="reg_email" size="30%"/><br><br></td>
						</tr>
					</div>
					<div class="form-group">
						<tr>
						<td><label for="password" style="margin:0px; padding:0px; font-size:13px;">Password (required)</label></td>
						</tr>
						<tr>
						<td><input type="password" class="form-control-center" id="reg_password" name="reg_password" size="30%"/><br><br></td>
						</tr>
					</div>
				</table>
				<table>
					<tr>
						<td><input type="submit" class="btn btn-success btn-md" value="Login" name="login_button"></td>
						<td><a href="index.php?page=signup#newuser" class="btn btn-default btn-md">Signup</a></td>
					</tr>
				</table>
			</form>
			</center>
        </div>
    
