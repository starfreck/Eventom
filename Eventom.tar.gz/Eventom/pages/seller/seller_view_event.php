<?php
include('pages/user_functions.php');
if($_SESSION['sid']==session_id() && $_SESSION['login_type']=='user')
{


?>
<div>
	<?php echo print_viewEvent(); ?>
</div>
<?php
	}
	else
	{
		header("location:index.php?page=login#loginuser");
	}
?>
