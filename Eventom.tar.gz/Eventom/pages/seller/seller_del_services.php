<?php
if($_SESSION['sid']==session_id() && $_SESSION['login_type']=='seller')
{

$email=$_SESSION['email'];

include'pages/connection.php';


?>
<!--Write Code Here....--> 
<center>
				
<form action="index.php?page=seller&subpage=seller_del_decoration" method="post" id="newuser">
<table>
<div class="form-group">
			<tr>
			<td><label style="margin:0px; padding:0px;"><h2>Delete Services</h2></label></td>
			</tr>
</div>                  
</table>
<font size="5px">Enter Service-ID Of Service Which You Want To Delete...</font>
			
<table>
<div class="form-group">
			<tr>
			<td>&nbsp;</td>
			</tr>			
			<tr>
			<td><label for="name" style="margin:0px; padding:0px; font-size:13px;">What You Want To Delete? (required)</label></td>
			</tr>
			<tr>
			<td>
			<select type="text" class="form-control-center" id="del_type" name="del_type" style="width:120px;">
				<option value="" selected></option>
				<option value="venue">Venue</option>
				<option value="food">Food</option>
				<option value="decoration">Decoration</option>
				<option value="facilities">Facilities</option>
			</select>
			</td>
			</tr>	
			<tr>
			<td>&nbsp;</td>
			</tr>			
			<tr>
			<td><label for="name" style="margin:0px; padding:0px; font-size:13px;">It's ID (required)</label></td>
			</tr>
			<tr>
			<td><input type="text" class="form-control-center" id="eid" name="eid" size="10%" value="0"/></td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			</tr>
                  

	<tr>
		<td><input type="submit" class="btn btn-danger btn-md" name="submit_button" value="Delete Service"></td>
	</tr>
</div>
</table>
</form>
</center> 

<?php
	
		
		
			if(isset($_POST['submit_button']))
			{
				
				$dtype = strval($_POST['del_type']);				
				$eid = strval($_POST['eid']);					
				if($eid==0)
				{
					
				}
				else
				{	
				// Create connection
					$conn = new mysqli($servername, $username, $password,$dbname);
				// Check connection
					if ($conn)
					{
						$sql = "SELECT owner FROM ".$dtype." WHERE id =".$eid;

						
							
						
							if($result=mysqli_query($conn,$sql))
							{
									$row = mysqli_fetch_array($result);
								  
									if($row['owner'] == $email)
									{
										$sql1 = "DELETE FROM ".$dtype." WHERE id=".$eid;
										if($row=mysqli_query($conn,$sql1)&& $eid!=null)
										{
										?>
										<div class="form-control-center">
										<center><h1 style="color:green;"><?php echo$dtype;?> Deleted</h1></center>
										</div>
										<?php
										}	
									}
								
								else
								{
									?>
									<div class="form-control-center">
									<center><h1 style="color:red;">You Have No Rights To Delete This <?php echo$dtype;?></h1></center>
									</div>
									<?php			
								}
							}
							else
							{?>
									<div class="form-control-center">
									<center><h1 style="color:red;"><?php echo$dtype;?> Not Deleted</h1></center>
									</div>
							<?php	
							}

						mysqli_close($conn);
					}
			
			


		}
	}	

	}
	else
	{
		header("location:index.php?page=login#loginuser");
	}

?>
