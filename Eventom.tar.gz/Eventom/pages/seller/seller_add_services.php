<?php
if($_SESSION['sid']==session_id() && $_SESSION['login_type']=='seller')
{

?>
<!--Write Code Here....--> 
<center>
				
<form action="index.php?page=seller&subpage=seller_add_services" method="post" id="newseller">
<table>


<div class="form-group">
			<tr>
			<td><label style="margin:0px; padding:0px;"><h2>Add Services</h2></label></td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td><label for="menu" style="margin:0px; padding:0px; font-size:13px;" name="service" id="service">Select Service (required)</label></td>
			</tr>
			<tr>
			<td>
			<select type="text" class="form-control-center" id="service_type" name="service_type" style="width:120px;">
				<option value="" selected></option>
				<option value="food">Food</option>
				<option value="decoration">Decoration</option>
				<option value="facilities">Facilities</option>
			</select>
			</td>
<tr>
			<td>&nbsp;</td>
			</tr>
			</tr>	
			<tr>
			<td><label for="venue_image" style="margin:0px; padding:0px; font-size:13px;" name="s_label" id="s_label">Service Name (required)</label></td>
			</tr>
			<tr>
			<td><input type="text" name="service_name"></td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td><label for="venue_cost" style="margin:0px; padding:0px; font-size:13px;">Service Cost (required)</label></td>
			</tr>
			<tr>
			<td><input type="number" name="service_cost"><br><br></td>
			</tr>
</div> 
</table>
<table>                   
	<tr>
	<td>&nbsp;</td>
	</tr>
	<tr>
	<td>&nbsp;</td>
	</tr>
	<tr>
	<td><input type="submit" class="btn btn-success btn-md" name="submit_button" value="Submit"/></td>
	</tr>

</table>
</form>
</center> 
<?php
	if(isset($_POST['submit_button']) && $_POST['service_name']!=null && $_POST['service_cost']!=null && $_POST['service_type']!=null)
	{
		$type=$_POST['service_type'];
		$name=$_POST['service_name'];
		$cost=$_POST['service_cost'];
		$owner=$_SESSION['email'];
	
		include'pages/connection.php';
		$conn = new mysqli($servername, $username, $password,$dbname);
		if ($conn)
		{

			$sql = "INSERT INTO ".$type." VALUES ('','$name','$cost','$owner')";
	
			$result_web = mysqli_query($conn,$sql);
	
			if($result_web)
			{	
				echo"<script>Successfully Added to Service list...</script>";
			}
	
	
	
		}
		mysqli_close($conn);
	}
	
	}
	else
	{
		header("location:index.php?page=login#loginuser");
	}


?>
   
