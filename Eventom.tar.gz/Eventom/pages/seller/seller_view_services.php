<?php
if($_SESSION['sid']==session_id() && $_SESSION['login_type']=='seller')
{
$email=$_SESSION['email'];

include'pages/connection.php';
$conn = new mysqli($servername, $username, $password,$dbname);
	
?>
<!--Write Code Here....--> 
<center>
				
<form action="index.php?page=seller&subpage=seller_view_services" method="post" id="newuser">
<table>
<div class="form-group">
			<tr>
			<td><label style="margin:0px; padding:0px;"><h2>View Services</h2></label></td>
			</tr>
</div>                  
</table>
<font size="5px">Choose Service Which You Want To View...</font>
			
<table>
<div class="form-group">
			<tr>
			<td>&nbsp;</td>
			</tr>			
			<tr>
			<td><label for="name" style="margin:0px; padding:0px; font-size:13px;">What You Want To View? (required)</label></td>
			</tr>
			<tr>
			<td>
			<select type="text" class="form-control-center" id="del_type" name="view_type" style="width:120px;">
				<option value="" selected></option>
				<option value="venue">Venue</option>
				<option value="food">Food</option>
				<option value="decoration">Decoration</option>
				<option value="facilities">Facilities</option>
			</select>
			</td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			</tr>				
			<tr>
			<td><input type="submit" class="btn btn-info btn-md" name="submit_button" value="View Service"></td>
			</tr>
</div>
</table>
</form>
</center> 
<?php
		if(isset($_POST['submit_button']) && $_POST['view_type']!=null )
			{
				
				$dtype = strval($_POST['view_type']);				
			if ($conn)
			{

			$result_web = mysqli_query($conn,"SELECT * FROM ".$dtype." WHERE owner ='$email'");
			echo"<center><br><br>";
			echo "<table style=\"font-size:20px\">";
	
			echo"<tr style=\"background-color:lightblue;\">";
			echo"<td align=\"center\">&nbsp;ID&nbsp;</td><td align=\"center\">&nbsp;Title&nbsp;</td><td align=\"center\">&nbsp;Cost&nbsp;</td>";
			echo"</tr>";
	
			$count=1;
			while($row = mysqli_fetch_array($result_web))
			{
		
				if(!($count %= 2)){echo"<tr style=\"background-color:lightgray;\">";}
				else{echo"<tr>";}
				echo"<td align=\"center\">&nbsp;".$row['id']."&nbsp;</td>";
				echo"<td align=\"center\">&nbsp;".$row['type']."&nbsp;</td>";
				echo"<td align=\"center\">&nbsp;".$row['cost']."&nbsp;</td>";
				echo"</tr>";
		
				$count++;
		
			}
			echo "</table>";
			echo"</center>";
	
		}
		mysqli_close($conn);
	}
}
else
{
	header("location:index.php?page=login#loginuser");
}
?>
