<?php
if($_SESSION['sid']==session_id() && $_SESSION['login_type']=='seller')
{

$email=$_SESSION['email'];
?>
<center>
				
<form action="index.php?page=seller&subpage=seller_add_venue" method="post" id="newseller" enctype = "multipart/form-data">
<table>


<div class="form-group">
			<tr>
			<td><label style="margin:0px; padding:0px;"><h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Add Venue</h2></label></td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			</tr>
			<td>&nbsp;</td>
			</tr>
			</tr>	
			<tr>
			<td><label for="venue_name" style="margin:0px; padding:0px; font-size:13px;" name="s_label" id="s_label">Venue Name (required)</label></td>
			<tr>
			<td><input type="text" name="service_name"></td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td><label for="venue_image" style="margin:0px; padding:0px; font-size:13px;" name="s_label" id="s_label">Venue Image (required)</label></td>
			</tr>
			
			<tr>
			<td><input type = "file" name = "image" /></td>
			</tr>
			<tr>
			<td>&nbsp;</td>
			</tr>
			<tr>
			<td><label for="venue_cost" style="margin:0px; padding:0px; font-size:13px;">Venue Cost (required)</label></td>
			</tr>
			<tr>
			<td><input type="number" name="service_cost"><br><br></td>
			</tr>
</div> 
</table>
<table>                   
	</tr>
	<tr>
	<td><input type="submit" class="btn btn-success btn-md" name="submit_button" value="Submit"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	</tr>

</table>
</form>
</center> 

<?php
	
	if(isset($_POST['submit_button']) && $_POST['service_name']!=null && $_POST['service_cost']!=null && $_FILES['image']!=null)
	{
		$img_path=null;
		$name=$_POST['service_name'];
		$cost=$_POST['service_cost'];
		$owner=$_SESSION['email'];
		
		if(isset($_FILES['image']))
		{
				      $errors= array();
				      $file_name = $_FILES['image']['name'];
				      $file_size = $_FILES['image']['size'];
				      $file_tmp = $_FILES['image']['tmp_name'];
				      $file_type = $_FILES['image']['type'];
					$tmp = explode('.',$_FILES['image']['name']);
					$file_extension = end($tmp);
				      $file_ext=strtolower($file_extension);
				      
				      $expensions= array("jpeg","jpg","png");
				      
				      if(in_array($file_ext,$expensions)=== false)
				      {
					 $errors[]="extension not allowed, please choose a JPEG or PNG file.";
				      }
				      
				      if($file_size > 2097152)
				      {
					 $errors[]='File size must be excately 2 MB';
				      }
				      
				      if(empty($errors)==true)
				      {
					 move_uploaded_file($file_tmp,"img/".$file_name);
						$img_path="img/".$file_name;
					 echo "<h2 style=\"color:green\">Success</h2>";
				      }else{
					 print_r($errors);
		      }
		}		
		
		

		include'pages/connection.php';
		
		$conn = new mysqli($servername, $username, $password,$dbname);

		if ($conn)
		{

			$sql = "INSERT INTO venue VALUES ('','$name','$img_path','$cost','$owner')";
	
			$result_web = mysqli_query($conn,$sql);
	
			if($result_web)
			{	
				echo"<script>Successfully Added to Venue list...</script>";
			}
	
	
	
		}
		mysqli_close($conn);
	}
				
	}
	else
	{
		header("location:index.php?page=login#loginuser");
	}



?>

